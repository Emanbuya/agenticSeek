# Save it as a new file called setup_searxng.sh
chmod +x setup_searxng.sh
./setup_searxng.sh